<?php
/**
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  IT-Solutions4You s.r.o. (ITS4YOU)
 * The Initial Developer of the Original Code is ITS4YOU.
 * Portions created by ITS4YOU are Copyright (C) ITS4YOU.
 * All Rights Reserved.
 */
require_once("modules/PDFMaker/checkGenerate.php");

exit;
?>